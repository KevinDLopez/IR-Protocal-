#include "tm4c123gh6pm.h"
#include <stdbool.h>
#include "Init.c"
#include <math.h> 




#define INDEX4ONE         60  //arrasy index to trasmit a one 
#define INDEX4ZERO        32 	// arrasy index to trasmit a zero
#define FIRST_BIT_CHECK   23 -1 
#define FIRST_BIT_CHECK2  25 -1 


/*
			TIMER IS 25 MicroSeconds pulse

			START PULSE IS 15000 MicroSeconds

			  	• Logical 1: 1.1ms low, 400us high 
   				• Logical 0: 400us low, 400us high    

   				We check between 575Ms and 625 Ms 
   								23rd   and 	25th bit
 		
*/

uint8_t START[60];// UP TO            1.5mS 
uint8_t ADDRESS_COMMAND[360];//UP TO 2 BITS   9mS
uint16_t AR_Count, addrCommCount;
bool START_FLAG = false;
bool SIGNAL_DONE = false;
bool STARTLOW = false;
uint8_t addrBitONe, addrBitTwo;
uint8_t dataBit1, dataBit2, dataBit3, dataBit4;

uint8_t data; //stores data form PB4





uint16_t secondBitTime, secondBitTime2;
uint16_t thirdBitTime, thirdBitTime2; 


uint16_t firstDaBitTime, firstDaBitTime2;
uint16_t secondDaBitTime, secondDaBitTime2; 
uint16_t thirdDaBitTime, thirdDaBitTime2;
uint16_t fourthDaBitTime, fourthDaBitTime2;

void check_start_bit(){



  
}


void checkAdd_1st_bit( ){ //ADDRESS MSB

          addrBitONe = 0; //assuming its a ZERO 
          secondBitTime =  FIRST_BIT_CHECK + INDEX4ZERO;
          secondBitTime2 = secondBitTime + 2; 

          for(int i = FIRST_BIT_CHECK; i < FIRST_BIT_CHECK2; i++){
	            if(ADDRESS_COMMAND[i] == 0){ // ITS A ONE
		              addrBitONe = 1;
		              secondBitTime =  FIRST_BIT_CHECK + INDEX4ONE;
		              secondBitTime2 = secondBitTime + 2; 
	            }//if
          }//for
        

}

void checkAdd_2nd_bit(){ //ADDRESS LSB 


      addrBitTwo = 0; //assuming its a high 
      firstDaBitTime =  secondBitTime + INDEX4ZERO;
      firstDaBitTime2 = firstDaBitTime + 2; 

      for(int i = secondBitTime; i < secondBitTime2; i++){
	        if(ADDRESS_COMMAND[i] == 0){ // ITS A ONE
		          addrBitTwo = 1;
		          firstDaBitTime =  secondBitTime + INDEX4ONE;
		          firstDaBitTime2 = firstDaBitTime + 2; 
	        }//if
      }//for


}

void check_1st_bit(){  //DATA MSB 


      dataBit1 = 0; //assuming its a high 
      secondDaBitTime =  firstDaBitTime + INDEX4ZERO;
      secondDaBitTime2 = secondDaBitTime + 2; 

      for(int i = firstDaBitTime; i < firstDaBitTime2; i++){
	        if(ADDRESS_COMMAND[i] == 0){ // ITS A ONE
		          dataBit1 = 1;
		          secondDaBitTime =  firstDaBitTime + INDEX4ONE;
		          secondDaBitTime2 = secondDaBitTime + 2; 
	        }//if
      }//for
}



void check_2nd_bit(){  


      dataBit2 = 0; //assuming its a high 
      thirdDaBitTime =  secondDaBitTime + INDEX4ZERO;
      thirdDaBitTime2 = thirdDaBitTime + 2; 

      for(int i = secondDaBitTime; i < secondDaBitTime2; i++){
	        if(ADDRESS_COMMAND[i] == 0){ // ITS A ONE
	          	dataBit2 = 1;
	     	 	thirdDaBitTime =  secondDaBitTime + INDEX4ONE;
	      		thirdDaBitTime2 = thirdDaBitTime + 2; 
	        }//if
      }//for
}




void check_3rth_bit(){  


      dataBit3 = 0; //assuming its a high 
      fourthDaBitTime =  thirdDaBitTime + INDEX4ZERO;
      fourthDaBitTime2 = fourthDaBitTime + 2; 

      for(int i = thirdDaBitTime; i < thirdDaBitTime2; i++){
	        if(ADDRESS_COMMAND[i] == 0){ // ITS A ONE
	          dataBit3 = 1;
		      fourthDaBitTime =  thirdDaBitTime + INDEX4ONE;
		      fourthDaBitTime2 = fourthDaBitTime + 2; 
	        }//if
      }//for
}


void check_4rth_bit(){  //DATA LSB 
 ////////////////////reset everything after done   


      dataBit4 = 0; //assuming its a high 

      for(int i = fourthDaBitTime; i < fourthDaBitTime2; i++){
	        if(ADDRESS_COMMAND[i] == 0){ // ITS A ONE
	          dataBit4 = 1;
	        	}//if

        }//for
        ////////	reset	 ///////////
		SIGNAL_DONE = true; 
		STARTLOW = false;

		 PORTB_INIT(); //enable interrupt again 
		 addrCommCount = 0;
		 AR_Count = 0;



}



uint8_t convertBinaryToDecimal(uint8_t msb, uint8_t thirdBinaryBit, uint8_t secondBinaryBit, uint8_t LSB )
{

    uint16_t decimalNumber = 0, i = 0, remainder, binaryNum = 0;

    binaryNum =  (msb*1000)   + 	(thirdBinaryBit*100) 	+ (secondBinaryBit*10) 	+  LSB;
    while (binaryNum!=0)
    {
        remainder = binaryNum%10;
        binaryNum /= 10;
        decimalNumber += remainder*pow(2,i);
        ++i;
    }
    return decimalNumber;
}



