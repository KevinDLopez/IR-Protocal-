/*
Kevin Lopez 
Cristian Lopez

ASUMING INVERTED LOGIC

Incoming data from PB4 

UART PB0-1
*/


#include <stdint.h>
#include "JYU_447V2.c"
#include "ST7735.h"


int main(void){
		PORTB_INIT(); 	//modulator comes from portB4 and interrupt is enable 
	  Timer1A_Init();  	// 25 microSeconds to check for data 
	  PLL_Init(); 		// 80Mhz
		UART1_poll_Init();
		ST7735_InitR(INITR_REDTAB);
		ST7735_FillScreen(0xFFFF);            // set screen to white	
		uint8_t command;
	  while(1){ 

		  	if ( (AR_Count >= 56) && (AR_Count <= 60) ){			
					////////////////////////---------Check Start pulse
					for(int i = 10; i < 32; i ++){ //ASUMING INVERTED LOGIC
							if (START[i] != 0) { //error 
								//reset count
								AR_Count = 0;
							}
					}
					
					for (int i = 45; i < 55; i++){
						if (START[i] == 0) {
							//reset count
							AR_Count = 0;

						}
					}
					//addrCommCount = 0;
		  	}// IF 60


		  	if   ( addrCommCount >= 360) {
		  		checkAdd_1st_bit(); //msb 
		  		checkAdd_2nd_bit();					
		  		check_1st_bit(); //msb 
		  		check_2nd_bit();
					check_3rth_bit();
					check_4rth_bit(); //lsb
					
					if ( (addrBitONe ==0) && (addrBitTwo ==0) ){ // if our device is being selected.

						
						command =  convertBinaryToDecimal( dataBit1, dataBit2, dataBit3, dataBit4 ) ;

						switch(command){
							case 0: 
								ST7735_FillScreen(0xFFFF);            // set screen to white
								ST7735_DrawString( 4, 6," Try again...lol", ST7735_WHITE, 1 );
								UART1_poll_Tx('N');
								break; 
							case 1: 
								ST7735_FillScreen(0xFFFF);            // set screen to white
								ST7735_DrawBitmap(20, 110, Athur, 90, 90); 
								DelayWait10ms(7);
								ST7735_DrawBitmap(22, 108, Athur, 90, 90); 
								DelayWait10ms(7);
								ST7735_DrawBitmap(24, 110, Athur, 90, 90); 
								DelayWait10ms(7);
								ST7735_DrawBitmap(22, 108, Athur, 90, 90); 
								DelayWait10ms(7);
								UART1_poll_Tx('N');
								break; 
							case 2: 
								ST7735_FillScreen(0xFFFF);            // set screen to white
								ST7735_DrawString(1, 0, "Hiii" , ST7735_RED, 5);
								DelayWait10ms(7);
								ST7735_DrawString(1, 1, "Hiii" , ST7735_RED, 5);
								DelayWait10ms(7);
								ST7735_DrawString(1, 2, "Hiii" , ST7735_RED, 5);
								DelayWait10ms(7);
								ST7735_DrawString(1, 3, "Hiii" , ST7735_RED, 5);
								DelayWait10ms(7);
								ST7735_DrawString(1, 4, "Hiii" , ST7735_RED, 5);
								DelayWait10ms(7);
								ST7735_FillScreen(0xFFFF);  // set screen to white
								ST7735_DrawString(1, 5, "Hiii" , ST7735_RED, 5);
								UART1_poll_Tx('N');
								break; //display something.		
							case 3: 
									ST7735_FillScreen(0xFFFF);            // set screen to white
									for(int i = 0; i < 120; i++){
									ST7735_FillCircle(65, 65, i, ST7735_BLUE);
									DelayWait10ms(5);
									}
									break;								
							case 4: 
								ST7735_FillScreen(0xFFFF);            // set screen to white
								ST7735_DrawBitmap(20, 110, Athur, 90, 90); 
								DelayWait10ms(90);
								ST7735_SetRotation(2);
								ST7735_DrawBitmap(20, 110, Athur, 90, 90); 
								DelayWait10ms(90);
								ST7735_SetRotation(3);
								ST7735_DrawBitmap(20, 110, Athur, 90, 90); 
								DelayWait10ms(90);
								ST7735_SetRotation(1);
								UART1_poll_Tx('N');
								break; 
							case 5: 
								UART1_poll_Tx('C');		
								ST7735_FillScreen(0xFFFF);            // set screen to white
								ST7735_DrawString( 4, 6," Playing node C", ST7735_WHITE, 1 );
								break; //send UART command to make sound
							case 6: 
								UART1_poll_Tx('D');		
								ST7735_FillScreen(0xFFFF);            // set screen to white
								ST7735_DrawString( 4, 6," Playing node D", ST7735_WHITE, 1 );
								break; //send UART command to make sound
							case 7: 
								UART1_poll_Tx('E');		
								ST7735_FillScreen(0xFFFF);            // set screen to white
								ST7735_DrawString( 4, 6," Playing node E", ST7735_WHITE, 1 );
								break; //send UART command to make sound
							case 8: 
								UART1_poll_Tx('F');		
								ST7735_FillScreen(0xFFFF);            // set screen to white
								ST7735_DrawString( 4, 6," Playing node F", ST7735_WHITE, 1 );
								break; //send UART command to make sound
							case 9: 
								UART1_poll_Tx('G');		
								ST7735_FillScreen(0xFFFF);            // set screen to white
								ST7735_DrawString( 4, 6," Playing node G", ST7735_WHITE, 1 );
								break; //send UART command to make sound
							case 10: 
								UART1_poll_Tx('A');		
								ST7735_FillScreen(0xFFFF);            // set screen to white
								ST7735_DrawString( 4, 6," Playing node A", ST7735_WHITE, 1 );
								break; //send UART command to make sound
							case 11: 
								UART1_poll_Tx('B');		
								ST7735_FillScreen(0xFFFF);            // set screen to white
								ST7735_DrawString( 4, 6," Playing node B", ST7735_WHITE, 1 );
								break; //send UART command to make sound
							default:
							  ST7735_FillScreen(0xFFFF);            // set screen to white
								ST7735_DrawString( 1, 6," Undefined Input", ST7735_WHITE, 1 );
								UART1_poll_Tx('N');		
								break; 
						}
					}

			}// if >360
		  	//check bits and do animation related to it.
		} //while 1

}//main

void GPIOPortB_Handler(void){ //THIS HAPPENDS EVERYTIME B IS LOW
	volatile int readback;

  	GPIO_PORTB_IM_R &= ~0x10;    // DISABLE INTERUPT
  	STARTLOW = 	true;

		GPIO_PORTB_ICR_R &= ~0x10;			// DISABLE INTERUPT
	
//	readback = GPIO_PORTB_ICR_R;	// force flag to clear
}


void Timer1A_Handler(void){
		volatile uint32_t readback;
		if(TIMER1_MIS_R & 0x01){			// Timer1A timeout flag is set

			data = GPIO_PORTB_DATA_R & 0x10; //CHECK DATA TAHT COMES FORM PORT PB4

			if (AR_Count < 60 && STARTLOW == true){
				START[AR_Count] = data;
				AR_Count++;
			}

			if   ( (AR_Count == 60)  && (STARTLOW == true) && (addrCommCount <= 360)  ){
				ADDRESS_COMMAND[addrCommCount] = data; 
				addrCommCount++;
			}

			TIMER1_ICR_R = 0x01;				// clear TimerA timeout flag
			readback = TIMER1_ICR_R;		// force interrupt flag clear
		}
		else{
			TIMER1_ICR_R = TIMER1_MIS_R;	// clear all flags
			readback = TIMER1_ICR_R;			// force interrupt flags clear
		}
}

